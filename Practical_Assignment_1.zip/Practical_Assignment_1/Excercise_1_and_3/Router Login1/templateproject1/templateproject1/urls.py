from django.contrib import admin
from django.conf.urls import url,include
from django.urls import path
from testapp import views
from rest_framework import routers

router=routers.DefaultRouter()
router.register('api',views.Router1_detailsDB_CRUD)


urlpatterns = [
    url('admin/', admin.site.urls),
    url(r'^$',views.Router_login),
    url(r'^Router_login',views.Router_login),
    url(r'^Router_details',views.Router_details),
    url(r'',include(router.urls)),
    path('api-auth/', include('rest_framework.urls',namespace='rest_framework')),

###################Router details###################

    url(r'^ZAIN/Router1_details',views.Router1_details),
    url(r'^ZAIN/Router2_details',views.Router2_details),


    ]
