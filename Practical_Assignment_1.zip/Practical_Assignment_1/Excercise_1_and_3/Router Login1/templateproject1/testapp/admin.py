from django.contrib import admin
from testapp.models import*

#######Router1_details#####

class Router1_detailsDBAdmin(admin.ModelAdmin):
    list_display=['id','Sapid','Hostname','Loopback','MacAddress']

admin.site.register(Router1_detailsDB,Router1_detailsDBAdmin)

#######Router2_details#####

class Router2_detailsDBAdmin(admin.ModelAdmin):
    list_display=['id','Sapid','Hostname','Loopback','MacAddress']

admin.site.register(Router2_detailsDB,Router2_detailsDBAdmin)
