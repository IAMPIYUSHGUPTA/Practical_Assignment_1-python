# Create your views here.
from django.shortcuts import render
from testapp.models import*
from django.views.generic import View
from rest_framework.viewsets import ModelViewSet
from testapp.serializers import Router1_detailsDBSerializer

def Router_login(request):
    return render (request,'testapp/AMS Project/Router_login.html')
def Router_details(request):
    return render (request,'testapp/AMS Project/Router_details.html')

#######################Router_details#####################
def Router1_details(request):
    employees=Router1_detailsDB.objects.all()
    return render (request,'testapp/AMS Project/ZAIN/Router1_details.html',{'employees':employees})
def Router2_details(request):
    employees=Router2_detailsDB.objects.all()
    return render (request,'testapp/AMS Project/ZAIN/Router2_details.html',{'employees':employees})

###########END#################END##############END############END##
class Router1_detailsDB_CRUD(ModelViewSet):
    queryset=Router1_detailsDB.objects.all()
    serializer_class=Router1_detailsDBSerializer
