from django.db import models

# Create your models here.
############Router1_details###########
class Router1_detailsDB (models.Model):
    Sapid=models.CharField(max_length=64)
    Hostname=models.CharField(max_length=64)
    Loopback=models.CharField(max_length=64)
    MacAddress=models.CharField(max_length=64)
############Router2_details###########
class Router2_detailsDB (models.Model):
    Sapid=models.CharField(max_length=64)
    Hostname=models.CharField(max_length=64)
    Loopback=models.CharField(max_length=64)
    MacAddress=models.CharField(max_length=64)
