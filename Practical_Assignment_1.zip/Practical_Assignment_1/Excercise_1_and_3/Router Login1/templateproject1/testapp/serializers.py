from testapp.models import Router1_detailsDB
from rest_framework.serializers import ModelSerializer



class Router1_detailsDBSerializer(ModelSerializer):
    class Meta:
        model =Router1_detailsDB
        fields='__all__'
