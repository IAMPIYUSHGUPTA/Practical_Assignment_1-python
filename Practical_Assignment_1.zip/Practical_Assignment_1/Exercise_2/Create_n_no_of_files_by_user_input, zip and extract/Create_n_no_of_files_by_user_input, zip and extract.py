##create multiple files using python, zip those, extract##
import zipfile
from glob import glob
import os

num=int(input("enter no of files to be created:"))
for item in range(1,(num+1)):
    open("File %s.txt" % item, "a").close()


##Now to zip the files##    
new_list =[]
for txt_files in (glob('*.txt')+ glob('*.png') + glob('*.ppt')):
    #print(txt_files)
    new_list.append(txt_files)
    my_zip = zipfile.ZipFile('Zippedfiles.zip','w',compression = zipfile.ZIP_DEFLATED)
    for data_files in new_list:
        my_zip.write(data_files)
my_zip.close()

##import requests
##import zipfile
##r=request.get('\\path\\') #if you want to download from server#
##
##with open('files.zip','wb') as f:
##        f.write(r.content)#to write the bytes we downloaded from link


##Now to extract##
zf = zipfile.ZipFile('Zippedfiles.zip', 'r')
os.mkdir('Extracted_folder')
zf.extractall('Extracted_folder')
zf.close()
