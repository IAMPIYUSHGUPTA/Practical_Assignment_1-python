import paramiko #uses sshv2 protocol to secure connection
server_ip = '192.168.1.1'
port=22
username=''
password=''



ssh_client=paramiko.SSHClient() #create a ssh client object- to create a SSH connectivity we need to create one client
ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy()) # auto except policy is automatically excepting all host keys and add it to known host file
ssh_client.connect(server_ip,port,username,password)  # to connect to the router


#stdin- standard input, data that goes into program ,password
#stdout- standard output, used by program to send data
#stderr-standard error, used by program to write any error msgs

stdin,stdout,stderr=ssh_client.exec_command('show ip interface brief')
output=stdout.readlines()
print('\n'.join(output))
ssh_client.close()#  to close ssh client

