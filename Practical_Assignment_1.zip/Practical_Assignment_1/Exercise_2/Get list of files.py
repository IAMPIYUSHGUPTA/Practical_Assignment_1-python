import os
path1="C:\\"
arr = os.listdir(path1)

for each in arr:
    print(each)
