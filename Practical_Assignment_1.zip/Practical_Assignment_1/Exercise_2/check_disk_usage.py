import shutil # importing shutil module  
  
# Path 
path = "C:\\Users\\eefiiku\\Desktop\\This PC.lnk" # path
  
# Get the disk usage statistics 
# about the given path 
total, used, free = shutil.disk_usage(path) 
  
# Print disk usage statistics 
print("Disk usage statistics:") 
print('Total space',total)
print('Used',used)
print('Free',free) 
