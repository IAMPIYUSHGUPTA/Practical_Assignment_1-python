import os
TotalBW=float(10000)
currentBW=float(8500)
c=float((currentBW/TotalBW)*100)
threshold_criteria = str(c) +'%'
print(threshold_criteria)
  
while c > 85:
    #os.system("shutdown /r /t 1")
    #shutdown /r /m \\pc2
    sudo systemctl restart apache2
