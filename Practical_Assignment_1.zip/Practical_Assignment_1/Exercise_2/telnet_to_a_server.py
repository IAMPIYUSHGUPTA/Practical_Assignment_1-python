#run this in commandprompt#

import getpass    #  to get the password
import telnetlib

HOST = "192.168.1.1"  #switchip
user = input("Enter your username: ")
password = getpass.getpass()

tn = telnetlib.Telnet(HOST)
#base code for telneting into a remote device
tn.read_until(b"Username: ")
tn.write(user.encode('ascii') + b"\n")
if password:
    tn.read_until(b"Password: ")
    tn.write(password.encode('ascii') + b"\n")
#script writing something onto remote end
tn.write(b"enable\n") # to enablemode, login to your switch in adminstratormode
tn.write(b"cisco\n")#password is cisco
tn.write(b"config t\n")# configure terminal
tn.write(b"interface lo 1\n")
tn.write(b"ip address 1.1.1.1 255.255.255.255\n") #going to create a new lookback address and assign an IP of 1.1.1.1 to this loopback address
tn.write(b"end\n")
tn.write(b"exit\n")

print(tn.read_all().decode('ascii')) # just prints all commands that you ran inside
