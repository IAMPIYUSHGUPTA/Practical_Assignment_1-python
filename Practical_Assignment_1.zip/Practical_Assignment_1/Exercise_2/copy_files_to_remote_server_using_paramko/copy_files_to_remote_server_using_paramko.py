import paramiko #uses sshv2 protocol to secure connection
server_ip = '192.168.1.1'
port=22
username='user1'
password='paramiko123'

ssh_client=paramiko.SSHClient() #create a ssh client object- to create a SSH connectivity we need to create one client
ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy()) # auto except policy is automatically excepting all host keys and add it to known host file
ssh_client.connect(server_ip,port,username,password)  # to connect to the router

sftp_client= ssh_client.open_sftp()  #to transfer a file from/to remote server, create from ssh client one sftp object # we are opening sftp connect with your remote server

##to download##
#sftp_client.get('C:\\Users\\eefiiku\\Desktop\\Piyush-iampiyushgupta@gmail.com\\cosi.txt','cvc.txt') #to store your cosi's content to cvc
sftp_client.chdir("\\Piyush-iampiyushgupta@gmail.com")
print(sftp_client.getcwd())
sftp_client.get('demo.txt','C:\\Users\\eefiiku\\Desktop\\Piyush-iampiyushgupta@gmail.com\\cosi.txt')

##to transfer file from local server to remote server##
##sftp_client.put('C:\\Users\\eefiiku\\Desktop\\Piyush-iampiyushgupta@gmail.com\\cosi.txt','\\cosi.txt')

sftp_client.close()
ssh_client.close()# better to close ssh client

